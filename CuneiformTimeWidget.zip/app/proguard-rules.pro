# Keep the app widget provider reachable by the framework.
-keep class com.example.cuneiformwidget.CuneiformTimeWidgetProvider { *; }
-keep class com.example.cuneiformwidget.BootReceiver { *; }
