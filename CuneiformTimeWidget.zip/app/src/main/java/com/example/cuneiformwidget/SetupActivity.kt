package com.example.cuneiformwidget

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout

/**
 * Mandatory first-run configuration. The launcher points here; on later starts
 * it forwards straight to [SettingsActivity]. It can also be reopened from
 * Settings (with [EXTRA_FORCE]) to change the choices.
 */
class SetupActivity : BaseActivity() {

    private var force = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        force = intent.getBooleanExtra(EXTRA_FORCE, false)
        if (!force && WidgetPreferences.isSetupDone(this)) {
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_setup)
        populateOptions()
        findViewById<Button>(R.id.setup_continue).setOnClickListener { finishSetup() }
    }

    private fun populateOptions() {
        val languageGroup = findViewById<LinearLayout>(R.id.setup_language_group)
        SettingsUi.radioGroup(
            this, languageGroup, AppLanguage.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getLanguage(this)
        ) { language ->
            WidgetPreferences.setLanguage(this, language)
            recreate() // re-render the screen in the chosen language
        }

        val formatGroup = findViewById<LinearLayout>(R.id.setup_format_group)
        SettingsUi.radioGroup(
            this, formatGroup, listOf(false, true),
            { getString(if (it) R.string.format_24h else R.string.format_12h) },
            WidgetPreferences.getUse24Hour(this)
        ) { use24Hour -> WidgetPreferences.setUse24Hour(this, use24Hour) }

        val modeGroup = findViewById<LinearLayout>(R.id.setup_mode_group)
        SettingsUi.radioGroup(
            this, modeGroup, DisplayMode.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getDisplayMode(this)
        ) { mode -> WidgetPreferences.setDisplayMode(this, mode) }

        val fontGroup = findViewById<LinearLayout>(R.id.setup_font_group)
        SettingsUi.radioGroup(
            this, fontGroup, FontStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getFontStyle(this)
        ) { font -> WidgetPreferences.setFontStyle(this, font) }

        val inkGroup = findViewById<LinearLayout>(R.id.setup_ink_group)
        SettingsUi.radioGroup(
            this, inkGroup, InkStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getInkStyle(this)
        ) { ink -> WidgetPreferences.setInkStyle(this, ink) }

        val backgroundGroup = findViewById<LinearLayout>(R.id.setup_theme_group)
        SettingsUi.radioGroup(
            this, backgroundGroup, BackgroundStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getBackgroundStyle(this)
        ) { background ->
            WidgetPreferences.setBackgroundStyle(this, background)
            applyThemeBackground()
        }
    }

    private fun finishSetup() {
        WidgetPreferences.setSetupDone(this, true)
        CuneiformTimeWidgetProvider.refreshAll(this)
        startActivity(
            Intent(this, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
        )
        finish()
    }

    companion object {
        const val EXTRA_FORCE = "com.example.cuneiformwidget.extra.FORCE_SETUP"
    }
}
