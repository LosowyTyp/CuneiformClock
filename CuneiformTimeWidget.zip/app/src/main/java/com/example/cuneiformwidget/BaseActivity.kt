package com.example.cuneiformwidget

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import java.util.Locale

/**
 * Base for all app screens. Applies the user's language (so switching it takes
 * effect after [android.app.Activity.recreate]) and the selected colour theme
 * to the window background.
 */
abstract class BaseActivity : Activity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(localizedContext(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyThemeBackground()
    }

    protected fun applyThemeBackground() {
        window.setBackgroundDrawable(
            ColorDrawable(WidgetPreferences.getBackgroundStyle(this).windowColor)
        )
    }

    private fun localizedContext(base: Context): Context {
        val locale = Locale(WidgetPreferences.getLanguage(base).code)
        Locale.setDefault(locale)
        val configuration = Configuration(base.resources.configuration).apply {
            setLocale(locale)
        }
        return base.createConfigurationContext(configuration)
    }
}
