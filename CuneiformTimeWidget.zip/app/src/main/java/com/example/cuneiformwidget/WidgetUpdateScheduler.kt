package com.example.cuneiformwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Schedules a once-per-minute alarm that wakes [CuneiformTimeWidgetProvider] so
 * the clock widget stays in sync with the current time. Widgets created with
 * RemoteViews cannot run code on their own, and `updatePeriodMillis` is capped
 * at 30 minutes, so an explicit alarm is the reliable way to tick every minute.
 */
object WidgetUpdateScheduler {

    /** Custom action delivered to the widget provider on every tick. */
    const val ACTION_TICK = "com.example.cuneiformwidget.action.TICK"

    private const val REQUEST_CODE = 0x5345 // "SE" (Sumerian)

    private const val MINUTE_MILLIS = 60_000L

    /** Small offset so the update lands just after the minute flips. */
    private const val GRACE_MILLIS = 250L

    /** Schedules the next tick, replacing any pending one. */
    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return

        val now = System.currentTimeMillis()
        val triggerAt = now - (now % MINUTE_MILLIS) + MINUTE_MILLIS + GRACE_MILLIS
        val operation = tickPendingIntent(context)

        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                !alarmManager.canScheduleExactAlarms() ->
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, operation)

            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ->
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, operation)

            else ->
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, operation)
        }
    }

    /** Cancels any pending tick (e.g. when the last widget is removed). */
    fun cancel(context: Context) {
        context.getSystemService(AlarmManager::class.java)?.cancel(tickPendingIntent(context))
    }

    /** PendingIntent that fires [ACTION_TICK] at [CuneiformTimeWidgetProvider]. */
    fun tickPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, CuneiformTimeWidgetProvider::class.java).apply {
            action = ACTION_TICK
        }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
