package com.example.cuneiformwidget

/**
 * How cuneiform marks are drawn in the widget and in the app preview.
 *
 *  - [CLUSTER] renders the authentic wedge shapes as paths (tens on the left,
 *    units in a 3x3 grid on the right).
 *  - [CLASSIC] lays out the bundled Noto Sans Cuneiform glyphs as text.
 */
enum class DisplayMode(val key: String, val labelRes: Int) {
    CLUSTER("cluster", R.string.mode_cluster),
    CLASSIC("classic", R.string.mode_classic);

    companion object {
        val DEFAULT = CLUSTER

        fun fromKey(key: String?): DisplayMode =
            values().firstOrNull { it.key == key } ?: DEFAULT
    }
}
