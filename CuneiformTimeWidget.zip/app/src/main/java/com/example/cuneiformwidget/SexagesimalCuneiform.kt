package com.example.cuneiformwidget

/**
 * Renders non-negative integers as authentic Sumerian / Babylonian cuneiform
 * numerals using the sexagesimal (base-60) system.
 *
 * Historical background
 * ---------------------
 * The Mesopotamian scribes used only two kinds of marks for their numerals:
 *
 *  - the vertical wedge, DIŠ, worth 1
 *  - the corner wedge (Winkelhaken), U, worth 10
 *
 * A single sexagesimal place (a "digit", 0..59) is written by counting tens with
 * corner wedges and units with vertical wedges, e.g.:
 *
 *      1  -> 𒐕
 *     10  -> 𒌋
 *     23  -> 𒌋𒌋𒐕𒐕𒐕        (2 x ten + 3 x one)
 *     59  -> 𒌋𒌋𒌋𒌋𒌋𒐕𒐕𒐕𒐕𒐕𒐕𒐕𒐕𒐕
 *
 * Larger numbers stack several places; the places are simply written side by
 * side (historically separated only by whitespace). The early system had no
 * symbol for zero, so a zero place renders as nothing ([ZERO]).
 */
object SexagesimalCuneiform {

    /** Vertical wedge (DIŠ) = 1.  Unicode U+12415 CUNEIFORM NUMERIC SIGN ONE GESH2. */
    val ONE: String = String(Character.toChars(0x12415))

    /** Corner wedge / Winkelhaken (U) = 10.  Unicode U+1230B CUNEIFORM SIGN U. */
    val TEN: String = String(Character.toChars(0x1230B))

    /**
     * Separator written between the sexagesimal places of a single number. The
     * scribes simply left a gap, so this is a plain space.
     */
    const val PLACE_SEPARATOR: String = " "

    /**
     * Divider drawn between two separate numbers, such as the hours and the
     * minutes of a time. Uses the authentic cuneiform punctuation sign U+12471
     * (VERTICAL COLON), which evokes a ":".
     */
    val TIME_SEPARATOR: String = String(Character.toChars(0x12471))

    /**
     * What to draw for an empty place. The Babylonians had no zero, so by
     * default this is empty. Replace it with the Seleucid-era placeholder if
     * you prefer a visible mark.
     */
    const val ZERO: String = ""

    /**
     * Renders a single sexagesimal digit (0..59) as cuneiform marks.
     *
     * @throws IllegalArgumentException if [value] is outside 0..59.
     */
    fun digit(value: Int): String {
        require(value in 0..59) { "sexagesimal digit must be 0..59 but was $value" }
        if (value == 0) return ZERO
        val tens = value / 10
        val ones = value % 10
        return TEN.repeat(tens) + ONE.repeat(ones)
    }

    /**
     * Renders any non-negative integer in full positional sexagesimal notation.
     * Places are joined with [PLACE_SEPARATOR]. For example 61 -> "𒐕 𒐕".
     *
     * @throws IllegalArgumentException if [value] is negative.
     */
    fun of(value: Int): String {
        require(value >= 0) { "value must be >= 0 but was $value" }
        if (value == 0) return ZERO

        val places = ArrayList<Int>(4)
        var n = value
        while (n > 0) {
            places.add(n % 60)
            n /= 60
        }
        places.reverse()
        return places.joinToString(PLACE_SEPARATOR) { digit(it) }
    }

    /**
     * Renders an hour/minute pair, each in its own place. Because both hours
     * (0..23) and minutes (0..59) fit in a single sexagesimal place, the result
     * reads as "<hours> : <minutes>".
     */
    fun time(hour: Int, minute: Int): String =
        digit(hour) + TIME_SEPARATOR + digit(minute)
}
