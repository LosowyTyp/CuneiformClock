package com.example.cuneiformwidget

import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import java.util.Calendar

/**
 * Main screen of the app: a live preview of the current time plus the option
 * lists (display style, time format, colour theme, language) and links to the
 * tutorial and to the first-run setup.
 */
class SettingsActivity : BaseActivity() {

    private lateinit var preview: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        preview = findViewById(R.id.settings_preview)

        findViewById<Button>(R.id.settings_tutorial).setOnClickListener {
            startActivity(Intent(this, TutorialActivity::class.java))
        }
        findViewById<Button>(R.id.settings_setup).setOnClickListener {
            startActivity(
                Intent(this, SetupActivity::class.java).putExtra(SetupActivity.EXTRA_FORCE, true)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        // The language may have changed while we were away (e.g. via Setup).
        val current = resources.configuration.locales[0].language
        if (current != WidgetPreferences.getLanguage(this).code) {
            recreate()
            return
        }
        populateOptions()
        applyThemeBackground()
        refreshPreview()
    }

    private fun populateOptions() {
        val modeGroup = findViewById<LinearLayout>(R.id.settings_mode_group)
        SettingsUi.radioGroup(
            this, modeGroup, DisplayMode.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getDisplayMode(this)
        ) { mode -> WidgetPreferences.setDisplayMode(this, mode); onOptionsChanged() }

        val fontGroup = findViewById<LinearLayout>(R.id.settings_font_group)
        SettingsUi.radioGroup(
            this, fontGroup, FontStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getFontStyle(this)
        ) { font -> WidgetPreferences.setFontStyle(this, font); onOptionsChanged() }

        val inkGroup = findViewById<LinearLayout>(R.id.settings_ink_group)
        SettingsUi.radioGroup(
            this, inkGroup, InkStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getInkStyle(this)
        ) { ink -> WidgetPreferences.setInkStyle(this, ink); onOptionsChanged() }

        val formatGroup = findViewById<LinearLayout>(R.id.settings_format_group)
        SettingsUi.radioGroup(
            this, formatGroup, listOf(false, true),
            { getString(if (it) R.string.format_24h else R.string.format_12h) },
            WidgetPreferences.getUse24Hour(this)
        ) { use24Hour -> WidgetPreferences.setUse24Hour(this, use24Hour); onOptionsChanged() }

        val themeGroup = findViewById<LinearLayout>(R.id.settings_theme_group)
        SettingsUi.radioGroup(
            this, themeGroup, BackgroundStyle.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getBackgroundStyle(this)
        ) { bg -> WidgetPreferences.setBackgroundStyle(this, bg); applyThemeBackground(); onOptionsChanged() }

        val languageGroup = findViewById<LinearLayout>(R.id.settings_language_group)
        SettingsUi.radioGroup(
            this, languageGroup, AppLanguage.values().toList(),
            { getString(it.labelRes) }, WidgetPreferences.getLanguage(this)
        ) { language ->
            WidgetPreferences.setLanguage(this, language)
            CuneiformTimeWidgetProvider.refreshAll(this)
            recreate()
        }
    }

    private fun onOptionsChanged() {
        refreshPreview()
        CuneiformTimeWidgetProvider.refreshAll(this)
    }

    private fun refreshPreview() {
        val calendar = Calendar.getInstance()
        val use24Hour = WidgetPreferences.getUse24Hour(this)
        val hour = TimeFormat.hourPlace(calendar.get(Calendar.HOUR_OF_DAY), use24Hour)
        val minute = TimeFormat.minutePlace(calendar.get(Calendar.MINUTE))

        val size = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, PREVIEW_BASE_DP, resources.displayMetrics
        )
        val ink = WidgetPreferences.getInkStyle(this)
        val bg = WidgetPreferences.getBackgroundStyle(this)
        preview.setBackgroundColor(bg.color)
        preview.setImageBitmap(
            CuneiformRenderer.render(
                this,
                hour,
                minute,
                size,
                ink.color,
                WidgetPreferences.getDisplayMode(this),
                WidgetPreferences.getFontStyle(this)
            )
        )
    }

    private companion object {
        const val PREVIEW_BASE_DP = 42f
    }
}
