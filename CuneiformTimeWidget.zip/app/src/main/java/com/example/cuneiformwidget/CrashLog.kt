package com.example.cuneiformwidget

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Debug helper: appends diagnostics / crash stack traces to a plain-text file
 * inside the app's external media dir (Android/media/<pkg>/crash.log), which is
 * readable by other apps (e.g. Termux) for troubleshooting.
 */
internal object CrashLog {

    private const val TAG = "CuneiformCrash"

    @Volatile
    private var cachedPath: String? = null

    private fun path(context: Context): String {
        cachedPath?.let { return it }
        val p = runCatching {
            val dirs = context.getExternalMediaDirs()
            if (dirs.isNotEmpty()) File(dirs[0], "crash.log").absolutePath
            else File(context.filesDir, "crash.log").absolutePath
        }.getOrElse { File(context.filesDir, "crash.log").absolutePath }
        cachedPath = p
        return p
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    /** Writes a stack trace (or an N/A marker) to the log file. */
    fun append(context: Context, tag: String, throwable: Throwable?) {
        val stack = throwable?.let { Log.getStackTraceString(it) } ?: "N/A"
        val text = "[${stamp()}] [$tag] $stack\n"
        Log.e(TAG, text)
        try {
            val f = File(path(context))
            f.parentFile?.mkdirs()
            f.appendText(text)
            Log.i(TAG, "crash log written to ${f.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "crash log write failed: $e")
        }
    }

    /** Writes an informational diagnostic line to the log file. */
    fun info(context: Context, tag: String, message: String) {
        val text = "[${stamp()}] [$tag] $message\n"
        try {
            val f = File(path(context))
            f.parentFile?.mkdirs()
            f.appendText(text)
        } catch (_: Exception) {
        }
    }
}