package com.example.cuneiformwidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Refreshes and re-arms the widget after events that invalidate the scheduled
 * alarm or the displayed time: device reboot, app update and clock/timezone
 * changes.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> {
                CuneiformTimeWidgetProvider.refreshAll(context)
                WidgetUpdateScheduler.schedule(context)
            }
        }
    }
}
