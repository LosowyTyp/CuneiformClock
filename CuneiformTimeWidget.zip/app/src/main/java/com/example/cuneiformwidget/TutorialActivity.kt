package com.example.cuneiformwidget

import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Explains the Sumerian/Babylonian sexagesimal number system and shows every
 * number from 0 to 59 drawn live by [CuneiformRenderer] in the user's chosen
 * display mode.
 */
class TutorialActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutorial)

        findViewById<Button>(R.id.tutorial_back).setOnClickListener { finish() }

        val mode = WidgetPreferences.getDisplayMode(this)

        fillRow(findViewById(R.id.tutorial_tens_row), listOf(10, 20, 30, 40, 50), mode, EXAMPLE_DP)
        fillRow(findViewById(R.id.tutorial_units_row), (1..9).toList(), mode, EXAMPLE_DP)
        fillGrid(findViewById(R.id.tutorial_grid), mode)
    }

    private fun fillRow(
        row: LinearLayout,
        values: List<Int>,
        mode: DisplayMode,
        sizeDp: Float
    ) {
        row.removeAllViews()
        values.forEach { row.addView(cell(it, mode, sizeDp, labelSp = 12f)) }
    }

    private fun fillGrid(grid: LinearLayout, mode: DisplayMode) {
        grid.removeAllViews()
        var value = 0
        while (value < 60) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            repeat(10) {
                row.addView(cell(value, mode, GRID_DP, labelSp = 10f))
                value++
            }
            grid.addView(row)
        }
    }

    /** One label + rendered digit, horizontally weighted to fill its parent. */
    private fun cell(
        value: Int,
        mode: DisplayMode,
        sizeDp: Float,
        labelSp: Float
    ): LinearLayout {
        val sizePx = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, sizeDp, resources.displayMetrics
        )
        val image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = value.toString()
            val ink = WidgetPreferences.getInkStyle(this@TutorialActivity)
            setImageBitmap(CuneiformRenderer.renderDigit(this@TutorialActivity, value, sizePx, ink.color, mode, WidgetPreferences.getFontStyle(this@TutorialActivity)))
        }
        val label = TextView(this).apply {
            text = value.toString()
            textSize = labelSp
            gravity = Gravity.CENTER_HORIZONTAL
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(image)
            addView(label)
        }
    }

    private companion object {
        const val EXAMPLE_DP = 30f
        const val GRID_DP = 20f
    }
}
