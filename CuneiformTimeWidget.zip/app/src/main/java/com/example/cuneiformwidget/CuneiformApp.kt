package com.example.cuneiformwidget

import android.app.Application

/**
 * Installs a crash hook that records uncaught exceptions to
 * /sdcard/Android/media/com.example.cuneiformwidget/crash.log so failures can
 * be diagnosed from a shell / Termux without adb.
 */
class CuneiformApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val default = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            CrashLog.append(this, "FATAL", throwable)
            default?.uncaughtException(thread, throwable)
        }
    }
}