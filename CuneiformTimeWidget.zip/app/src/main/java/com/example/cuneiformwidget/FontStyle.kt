package com.example.cuneiformwidget

/**
 * Rendering style for cuneiform marks.
 *
 * [GEOMETRIC] draws the wedge shapes as vector paths (authentic, crisp at all
 * sizes and works regardless of font availability).
 * [NOTO_TTF] draws the bundled Noto Sans Cuneiform glyphs via the TTF font.
 */
enum class FontStyle(val key: String, val labelRes: Int) {
    GEOMETRIC("geometric", R.string.font_geometric),
    NOTO_TTF("noto_ttf", R.string.font_noto);

    companion object {
        val DEFAULT = GEOMETRIC

        fun fromKey(key: String?): FontStyle =
            values().firstOrNull { it.key == key } ?: DEFAULT
    }
}
