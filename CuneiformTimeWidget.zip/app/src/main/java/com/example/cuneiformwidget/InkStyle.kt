package com.example.cuneiformwidget

import android.graphics.Color

/**
 * Ink colour used to draw the cuneiform marks.
 */
enum class InkStyle(val key: String, val color: Int, val labelRes: Int) {
    CREAM("cream", 0xFFF2E6C9.toInt(), R.string.ink_cream),
    GOLD("gold", 0xFFE8C06A.toInt(), R.string.ink_gold),
    WHITE("white", Color.WHITE, R.string.ink_white),
    YELLOW("yellow", Color.YELLOW, R.string.ink_yellow);

    companion object {
        val DEFAULT = CREAM

        fun fromKey(key: String?): InkStyle =
            values().firstOrNull { it.key == key } ?: DEFAULT
    }
}
