package com.example.cuneiformwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.TypedValue
import android.widget.RemoteViews
import java.util.Calendar

/**
 * Home screen widget that shows the current time using Babylonian cuneiform
 * (sexagesimal) numerals.
 *
 * Hours and minutes are each one sexagesimal place, in 12- or 24-hour form as
 * chosen by the user. The marks are drawn to a [android.graphics.Bitmap] by
 * [CuneiformRenderer] and handed to the launcher as an image, so the result
 * does not depend on the launcher's font support.
 *
 * Every entry point is guarded so a single bad widget update can never crash
 * the app; failures are written to the crash log instead.
 */
class CuneiformTimeWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        try {
            appWidgetIds.forEach { render(context, appWidgetManager, it) }
        } catch (t: Throwable) {
            CrashLog.append(context, "onUpdate", t)
        }
        WidgetUpdateScheduler.schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == WidgetUpdateScheduler.ACTION_TICK) {
            try {
                refreshAll(context)
            } catch (t: Throwable) {
                CrashLog.append(context, "tick", t)
            }
            WidgetUpdateScheduler.schedule(context)
        }
    }

    override fun onEnabled(context: Context) {
        WidgetUpdateScheduler.schedule(context)
    }

    override fun onDisabled(context: Context) {
        WidgetUpdateScheduler.cancel(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        try {
            render(context, appWidgetManager, appWidgetId)
        } catch (t: Throwable) {
            CrashLog.append(context, "optionsChanged", t)
        }
    }

    companion object {

        private const val DEFAULT_HEIGHT_DP = 60f

        /** Re-renders every instance of this widget. */
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, CuneiformTimeWidgetProvider::class.java)
            )
            ids.forEach { render(context, manager, it) }
        }

        /** Reads the current time and pushes it into the given widget instance. */
        fun render(context: Context, manager: AppWidgetManager, widgetId: Int) {
            try {
                renderInternal(context, manager, widgetId)
            } catch (t: Throwable) {
                // Never let an update crash the (broadcast-receiver) app process.
                CrashLog.append(context, "render", t)
            }
        }

        private fun renderInternal(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val calendar = Calendar.getInstance()
            val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val use24Hour = WidgetPreferences.getUse24Hour(context)
            val fontStyle = WidgetPreferences.getFontStyle(context)
            val bg = WidgetPreferences.getBackgroundStyle(context)
            val ink = WidgetPreferences.getInkStyle(context)

            val hour = TimeFormat.hourPlace(hour24, use24Hour)
            val minutePlace = TimeFormat.minutePlace(minute)

            val textSizePx = textSizeFor(context, manager, widgetId)
            val bitmap = CuneiformRenderer.render(
                context, hour, minutePlace, textSizePx, ink.color, WidgetPreferences.getDisplayMode(context), fontStyle
            )

            val views = RemoteViews(context.packageName, R.layout.widget_cuneiform_time)
            views.setImageViewBitmap(R.id.widget_time, bitmap)
            views.setInt(R.id.widget_root, "setBackgroundColor", bg.color)

            // Tapping the widget forces an immediate refresh.
            views.setOnClickPendingIntent(
                R.id.widget_root,
                WidgetUpdateScheduler.tickPendingIntent(context)
            )

            manager.updateAppWidget(widgetId, views)
        }

        /** Sizes the glyphs from the widget's current height, with a sane default. */
        private fun textSizeFor(
            context: Context,
            manager: AppWidgetManager,
            widgetId: Int
        ): Float {
            val options = manager.getAppWidgetOptions(widgetId)
            val heightDp = options
                .getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, DEFAULT_HEIGHT_DP.toInt())
                .toFloat()
                .takeIf { it > 0f } ?: DEFAULT_HEIGHT_DP
            val basePx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                heightDp * 0.6f,
                context.resources.displayMetrics
            )
            // The renderer caps the resulting bitmap area regardless.
            return basePx * WidgetPreferences.getSizePercent(context) / 100f
        }
    }
}