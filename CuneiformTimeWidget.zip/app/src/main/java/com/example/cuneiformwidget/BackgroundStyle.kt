package com.example.cuneiformwidget

import android.graphics.Color

/**
 * Widget/app background style.
 */
enum class BackgroundStyle(val key: String, val color: Int, val windowColor: Int, val labelRes: Int) {
    CLAY("clay", 0xFF3B2F1E.toInt(), 0xFF3B2F1E.toInt(), R.string.bg_clay),
    NIGHT("night", Color.BLACK, Color.BLACK, R.string.bg_night),
    LAPIS("lapis", 0xFF12203A.toInt(), 0xFF12203A.toInt(), R.string.bg_lapis),
    TRANSPARENT("transparent", Color.TRANSPARENT, Color.BLACK, R.string.bg_transparent);

    companion object {
        val DEFAULT = CLAY

        fun fromKey(key: String?): BackgroundStyle =
            values().firstOrNull { it.key == key } ?: DEFAULT
    }
}
