package com.example.cuneiformwidget

/**
 * Pure helpers for turning a wall-clock time into the two sexagesimal places
 * the renderer expects. Kept free of Android types so it can be unit tested.
 */
object TimeFormat {

    /**
     * The hour as shown on the clock, still a single sexagesimal place:
     * 0..23 in 24-hour mode, or 1..12 in 12-hour mode.
     */
    fun hourPlace(hour24: Int, use24Hour: Boolean): Int =
        if (use24Hour) hour24.coerceIn(0, 23) else ((hour24 % 24 + 11) % 12) + 1

    /** The minute is already a single sexagesimal place (0..59). */
    fun minutePlace(minute: Int): Int = minute.coerceIn(0, 59)
}
