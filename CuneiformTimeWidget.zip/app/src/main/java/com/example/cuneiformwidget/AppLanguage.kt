package com.example.cuneiformwidget

/** Interface languages offered by the first-run setup and the settings screen. */
enum class AppLanguage(val code: String, val labelRes: Int) {
    ENGLISH("en", R.string.language_english),
    POLISH("pl", R.string.language_polish);

    companion object {
        val DEFAULT = ENGLISH

        fun fromCode(code: String?): AppLanguage =
            values().firstOrNull { it.code == code } ?: DEFAULT
    }
}
