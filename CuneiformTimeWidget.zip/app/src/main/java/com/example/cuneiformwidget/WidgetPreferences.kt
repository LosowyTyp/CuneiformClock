package com.example.cuneiformwidget

import android.content.Context

internal object WidgetPreferences {

    private const val PREFS = "cuneiform_widget"
    private const val KEY_SIZE_PERCENT = "size_percent"
    private const val KEY_DISPLAY_MODE = "display_mode"
    private const val KEY_FONT_STYLE = "font_style"
    private const val KEY_INK_STYLE = "ink_style"
    private const val KEY_BACKGROUND_STYLE = "background_style"
    private const val KEY_USE_24_HOUR = "use_24_hour"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_SETUP_DONE = "setup_done"

    const val MIN_PERCENT = 50
    const val MAX_PERCENT = 200
    const val STEP = 5
    const val DEFAULT_PERCENT = 100

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getSizePercent(context: Context): Int = prefs(context).getInt(KEY_SIZE_PERCENT, DEFAULT_PERCENT).coerceIn(MIN_PERCENT, MAX_PERCENT)
    fun setSizePercent(context: Context, percent: Int) { prefs(context).edit().putInt(KEY_SIZE_PERCENT, percent.coerceIn(MIN_PERCENT, MAX_PERCENT)).apply() }

    fun getDisplayMode(context: Context): DisplayMode = DisplayMode.fromKey(prefs(context).getString(KEY_DISPLAY_MODE, null))
    fun setDisplayMode(context: Context, mode: DisplayMode) { prefs(context).edit().putString(KEY_DISPLAY_MODE, mode.key).apply() }

    fun getFontStyle(context: Context): FontStyle = FontStyle.fromKey(prefs(context).getString(KEY_FONT_STYLE, null))
    fun setFontStyle(context: Context, style: FontStyle) { prefs(context).edit().putString(KEY_FONT_STYLE, style.key).apply() }

    fun getInkStyle(context: Context): InkStyle = InkStyle.fromKey(prefs(context).getString(KEY_INK_STYLE, null))
    fun setInkStyle(context: Context, style: InkStyle) { prefs(context).edit().putString(KEY_INK_STYLE, style.key).apply() }

    fun getBackgroundStyle(context: Context): BackgroundStyle = BackgroundStyle.fromKey(prefs(context).getString(KEY_BACKGROUND_STYLE, null))
    fun setBackgroundStyle(context: Context, style: BackgroundStyle) { prefs(context).edit().putString(KEY_BACKGROUND_STYLE, style.key).apply() }

    fun getUse24Hour(context: Context): Boolean = prefs(context).getBoolean(KEY_USE_24_HOUR, false)
    fun setUse24Hour(context: Context, use24Hour: Boolean) { prefs(context).edit().putBoolean(KEY_USE_24_HOUR, use24Hour).apply() }

    fun getLanguage(context: Context): AppLanguage = AppLanguage.fromCode(prefs(context).getString(KEY_LANGUAGE, null))
    fun setLanguage(context: Context, language: AppLanguage) { prefs(context).edit().putString(KEY_LANGUAGE, language.code).apply() }

    fun isSetupDone(context: Context): Boolean = prefs(context).getBoolean(KEY_SETUP_DONE, false)
    fun setSetupDone(context: Context, done: Boolean) { prefs(context).edit().putBoolean(KEY_SETUP_DONE, done).apply() }
}
