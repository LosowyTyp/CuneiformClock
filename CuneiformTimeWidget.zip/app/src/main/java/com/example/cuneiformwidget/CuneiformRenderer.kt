package com.example.cuneiformwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Rasterises sexagesimal (base-60) numerals into a [Bitmap] for the widget and
 * the app preview / tutorial.
 *
 * Two orthogonal choices drive the output:
 *
 *  - the **notation system** ([DisplayMode]) picks the *layout*:
 *    [DisplayMode.CLUSTER] groups the tens (corner wedges) on the left and the
 *    units (vertical wedges) in a 3x3 grid on the right, while
 *    [DisplayMode.CLASSIC] lays every mark out in one horizontal line, matching
 *    the plain Unicode text form.
 *  - the **font** ([FontStyle]) picks *how* every mark is drawn:
 *    [FontStyle.GEOMETRIC] draws crisp vector wedges, [FontStyle.NOTO_TTF]
 *    draws the bundled Noto Sans Cuneiform glyphs.
 *
 * Any combination of the two is valid. The finished image is capped to a small
 * pixel area ([MAX_BITMAP_AREA]) so the RemoteViews binder transaction never
 * overflows and the launcher (which scales with `fitCenter`) never clips.
 */
internal object CuneiformRenderer {

    private const val FONT_ASSET = "noto_sans_cuneiform.ttf"

    /** Gap between the number groups is a fraction of the text size. */
    private const val GAP_FRACTION = 0.35f

    /** Padding around the content, as a fraction of the text size. */
    private const val PAD_FRACTION = 0.15f

    /** Gap between marks in the linear (CLASSIC) layout. */
    private const val CLASSIC_GAP = 0.06f

    /** How big a Noto glyph is drawn relative to the cell it sits in. */
    private const val GLYPH_SIZE_FACTOR = 1.25f

    /** Hard cap on bitmap pixel area (px^2), well below the 1 MB binder limit. */
    private const val MAX_BITMAP_AREA = 240_000

    // --- Wedge geometry, all as fractions of the nominal text size `s` --------

    private const val V_WEDGE_W = 0.17f
    private const val V_WEDGE_H = 0.46f
    private const val V_GAP_X = 0.11f
    private const val V_GAP_Y = 0.09f

    private const val C_WEDGE_W = 0.34f
    private const val C_WEDGE_H = 0.26f
    private const val C_GAP_X = 0.07f

    private const val BLOCK_GAP = 0.24f
    private const val ZERO_W = 0.17f

    /** Which primitive a mark is. */
    private enum class Kind { TEN, UNIT }

    /** A single primitive mark, positioned by its centre. */
    private class Cell(
        val kind: Kind,
        val cx: Float,
        val cy: Float,
        val w: Float,
        val h: Float
    )

    /** The marks of one sexagesimal place plus its bounding box. */
    private class Digit(val cells: List<Cell>, val width: Float, val height: Float)

    @Volatile
    private var cachedTypeface: Typeface? = null

    private fun cuneiformTypeface(context: Context): Typeface? {
        cachedTypeface?.let { return it }
        return try {
            Typeface.createFromAsset(context.assets, FONT_ASSET).also { cachedTypeface = it }
        } catch (e: Exception) {
            null
        }
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /**
     * Renders `hour` and `minute` (each already a single sexagesimal place,
     * 0..59) separated by a cuneiform colon. Never throws; on any failure it
     * falls back to plain "H:MM" digits.
     */
    fun render(
        context: Context,
        hour: Int,
        minute: Int,
        textSizePx: Float,
        color: Int,
        mode: DisplayMode,
        fontStyle: FontStyle
    ): Bitmap {
        return try {
            when (fontStyle) {
                FontStyle.GEOMETRIC -> renderGeometricTime(hour, minute, textSizePx, color, mode)
                FontStyle.NOTO_TTF -> {
                    val typeface = cuneiformTypeface(context)
                    if (typeface == null) {
                        renderFallback(hour, minute, textSizePx, color)
                    } else {
                        when (mode) {
                            DisplayMode.CLASSIC ->
                                renderClassicTime(typeface, hour, minute, textSizePx, color)
                            DisplayMode.CLUSTER ->
                                renderNotoClusterTime(typeface, hour, minute, textSizePx, color)
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            CrashLog.append(context, "render", t)
            runCatching { renderFallback(hour, minute, textSizePx, color) }
                .getOrElse { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
        }
    }

    /**
     * Renders a single sexagesimal digit (0..59) with no separator. Used by the
     * tutorial grid. Never throws.
     */
    fun renderDigit(
        context: Context,
        value: Int,
        textSizePx: Float,
        color: Int,
        mode: DisplayMode,
        fontStyle: FontStyle
    ): Bitmap {
        return try {
            when (fontStyle) {
                FontStyle.GEOMETRIC -> renderGeometricDigit(value, textSizePx, color, mode)
                FontStyle.NOTO_TTF -> {
                    val typeface = cuneiformTypeface(context)
                    if (typeface == null) {
                        renderFallback(value, 0, textSizePx, color)
                    } else {
                        renderNotoDigit(typeface, value, textSizePx, color, mode)
                    }
                }
            }
        } catch (t: Throwable) {
            CrashLog.append(context, "renderDigit", t)
            runCatching { renderFallback(value, 0, textSizePx, color) }
                .getOrElse { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888) }
        }
    }

    // =========================================================================
    // Layout (independent of the font)
    // =========================================================================

    private fun layout(value: Int, size: Float, mode: DisplayMode): Digit = when (mode) {
        DisplayMode.CLUSTER -> layoutCluster(value, size)
        DisplayMode.CLASSIC -> layoutClassic(value, size)
    }

    /**
     * Grouped layout: the tens (corner wedges) sit on the left, the units
     * (vertical wedges) form a 3x3 grid on the right.
     */
    private fun layoutCluster(value: Int, size: Float): Digit {
        require(value in 0..59) { "sexagesimal digit must be 0..59 but was $value" }

        val tens = value / 10
        val units = value % 10
        val cells = ArrayList<Cell>()

        val vw = V_WEDGE_W * size
        val vh = V_WEDGE_H * size
        val vgx = V_GAP_X * size
        val vgy = V_GAP_Y * size
        val cw = C_WEDGE_W * size
        val ch = C_WEDGE_H * size
        val cgx = C_GAP_X * size
        val blockGap = BLOCK_GAP * size

        if (value == 0) return Digit(cells, ZERO_W * size, C_WEDGE_H * size)

        val rows = cuneiformUnitRows(units)
        val columns = rows.maxOrNull() ?: 0

        val tensWidth = if (tens > 0) tens * cw + (tens - 1) * cgx else 0f
        val tensHeight = if (tens > 0) ch else 0f
        val unitsWidth = if (columns > 0) columns * vw + (columns - 1) * vgx else 0f
        val unitsHeight = if (rows.isNotEmpty())
            rows.size * vh + (rows.size - 1) * vgy else 0f

        val clusterWidth = tensWidth + (if (tensWidth > 0 && unitsWidth > 0) blockGap else 0f) +
            unitsWidth
        val clusterHeight = max(tensHeight, unitsHeight)

        if (tens > 0) {
            val top = (clusterHeight - tensHeight) / 2f
            for (t in 0 until tens) {
                cells += Cell(Kind.TEN, t * (cw + cgx) + cw / 2f, top + ch / 2f, cw, ch)
            }
        }

        if (rows.isNotEmpty()) {
            val unitsLeft = tensWidth + (if (tensWidth > 0) blockGap else 0f)
            val unitsTop = (clusterHeight - unitsHeight) / 2f
            var rowTop = unitsTop
            for (count in rows) {
                val rowWidth = count * vw + (count - 1) * vgx
                val rowLeft = unitsLeft + (unitsWidth - rowWidth) / 2f
                for (c in 0 until count) {
                    cells += Cell(
                        Kind.UNIT,
                        rowLeft + c * (vw + vgx) + vw / 2f,
                        rowTop + vh / 2f,
                        vw,
                        vh
                    )
                }
                rowTop += vh + vgy
            }
        }

        return Digit(cells, clusterWidth, clusterHeight)
    }

    /**
     * Linear layout: every mark in one horizontal line, tens first, matching the
     * plain Unicode form produced by [SexagesimalCuneiform.digit].
     */
    private fun layoutClassic(value: Int, size: Float): Digit {
        require(value in 0..59) { "sexagesimal digit must be 0..59 but was $value" }

        if (value == 0) return Digit(emptyList(), ZERO_W * size, C_WEDGE_H * size)

        val tens = value / 10
        val units = value % 10
        val vw = V_WEDGE_W * size
        val vh = V_WEDGE_H * size
        val cw = C_WEDGE_W * size
        val ch = C_WEDGE_H * size
        val gap = C_GAP_X * size

        val kinds = ArrayList<Kind>(tens + units)
        repeat(tens) { kinds += Kind.TEN }
        repeat(units) { kinds += Kind.UNIT }

        val height = max(ch, vh)
        val cells = ArrayList<Cell>(kinds.size)
        var x = 0f
        for ((index, kind) in kinds.withIndex()) {
            val w = if (kind == Kind.TEN) cw else vw
            val h = if (kind == Kind.TEN) ch else vh
            cells += Cell(kind, x + w / 2f, height / 2f, w, h)
            x += w
            if (index != kinds.lastIndex) x += gap
        }

        return Digit(cells, x, height)
    }

    /**
     * Splits a units value (0..9) into the historic row pattern, top row first:
     * 1..3 sit in one row, 4..6 use two rows, 7..9 use three rows of at most
     * three wedges.
     */
    internal fun cuneiformUnitRows(units: Int): List<Int> = when (units) {
        0 -> emptyList()
        1, 2, 3 -> listOf(units)
        4 -> listOf(2, 2)
        5 -> listOf(3, 2)
        6 -> listOf(3, 3)
        7 -> listOf(3, 3, 1)
        8 -> listOf(3, 3, 2)
        else -> listOf(3, 3, 3) // 9
    }

    // =========================================================================
    // Vector (geometric) drawing
    // =========================================================================

    private class Separator(val path: Path, val width: Float, val height: Float)

    private fun renderGeometricTime(
        hour: Int,
        minute: Int,
        textSizePx: Float,
        color: Int,
        mode: DisplayMode
    ): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            this.color = color
        }

        var size = textSizePx.coerceAtLeast(1f)
        var hours = layout(hour, size, mode)
        var minutes = layout(minute, size, mode)
        var separator = buildSeparator(size)
        var gap = size * GAP_FRACTION
        var pad = size * PAD_FRACTION

        repeat(4) {
            val area = (hours.width + gap + separator.width + gap + minutes.width + pad * 2) *
                (maxOf(hours.height, separator.height, minutes.height) + pad * 2)
            if (area <= MAX_BITMAP_AREA) return@repeat
            size *= sqrt(MAX_BITMAP_AREA.toFloat() / area)
            hours = layout(hour, size, mode)
            minutes = layout(minute, size, mode)
            separator = buildSeparator(size)
            gap = size * GAP_FRACTION
            pad = size * PAD_FRACTION
        }

        val totalWidth = hours.width + gap + separator.width + gap + minutes.width
        val totalHeight = maxOf(hours.height, separator.height, minutes.height)
        val centerY = pad + totalHeight / 2f

        val bitmap = Bitmap.createBitmap(
            ceil(totalWidth + pad * 2).toInt().coerceAtLeast(1),
            ceil(totalHeight + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        Canvas(bitmap).apply {
            var x = pad
            drawDigitPath(this, paint, hours, x, centerY)
            x += hours.width + gap
            drawSeparator(this, paint, separator, x, centerY)
            x += separator.width + gap
            drawDigitPath(this, paint, minutes, x, centerY)
        }
        return bitmap
    }

    private fun renderGeometricDigit(value: Int, textSizePx: Float, color: Int, mode: DisplayMode): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            this.color = color
        }
        val size = textSizePx.coerceAtLeast(1f)
        val digit = layout(value, size, mode)
        val pad = size * PAD_FRACTION
        val bitmap = Bitmap.createBitmap(
            ceil(digit.width + pad * 2).toInt().coerceAtLeast(1),
            ceil(digit.height + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        Canvas(bitmap).apply { drawDigitPath(this, paint, digit, pad, pad + digit.height / 2f) }
        return bitmap
    }

    private fun drawDigitPath(canvas: Canvas, paint: Paint, digit: Digit, left: Float, centerY: Float) {
        if (digit.cells.isEmpty()) return
        val path = Path()
        for (cell in digit.cells) {
            val l = left + cell.cx - cell.w / 2f
            val t = centerY - digit.height / 2f + cell.cy - cell.h / 2f
            when (cell.kind) {
                Kind.TEN -> addCornerWedge(path, l, t, cell.w, cell.h)
                Kind.UNIT -> addVerticalWedge(path, l, t, cell.w, cell.h)
            }
        }
        canvas.drawPath(path, paint)
    }

    private fun drawSeparator(canvas: Canvas, paint: Paint, separator: Separator, left: Float, centerY: Float) {
        canvas.save()
        canvas.translate(left, centerY - separator.height / 2f)
        canvas.drawPath(separator.path, paint)
        canvas.restore()
    }

    private fun buildSeparator(size: Float): Separator {
        val w = V_WEDGE_W * size * 0.85f
        val h = V_WEDGE_H * size * 0.32f
        val gap = V_GAP_Y * size * 0.7f
        val path = Path()
        addVerticalWedge(path, 0f, 0f, w, h)
        addVerticalWedge(path, 0f, h + gap, w, h)
        return Separator(path, w, h * 2f + gap)
    }

    private fun addVerticalWedge(path: Path, left: Float, top: Float, w: Float, h: Float) {
        path.moveTo(left, top)
        path.lineTo(left + w, top)
        path.lineTo(left + w * 0.6f, top + h)
        path.lineTo(left + w * 0.4f, top + h)
        path.close()
    }

    private fun addCornerWedge(path: Path, left: Float, top: Float, w: Float, h: Float) {
        path.moveTo(left + w, top)
        path.lineTo(left + w, top + h)
        path.lineTo(left, top + h * 0.5f)
        path.close()
    }

    // =========================================================================
    // Noto Sans Cuneiform drawing
    // =========================================================================

    /**
     * Classic system + Noto font: draw each place as a single cuneiform glyph.
     */
    private fun renderClassicTime(
        typeface: Typeface,
        hour: Int,
        minute: Int,
        textSizePx: Float,
        color: Int
    ): Bitmap {
        val hours = SexagesimalCuneiform.digit(hour)
        val minutes = SexagesimalCuneiform.digit(minute)
        val separator = SexagesimalCuneiform.TIME_SEPARATOR

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            this.color = color
        }

        if (!paint.hasGlyph(SexagesimalCuneiform.ONE) ||
            !paint.hasGlyph(SexagesimalCuneiform.TEN) ||
            !paint.hasGlyph(separator)
        ) {
            return renderFallback(hour, minute, textSizePx, color)
        }

        var size = textSizePx.coerceAtLeast(1f)
        var hourWidth = 0f
        var minuteWidth = 0f
        var sepWidth = 0f
        var textHeight = 0f

        repeat(4) {
            paint.textSize = size
            hourWidth = paint.measureText(hours)
            minuteWidth = paint.measureText(minutes)
            sepWidth = paint.measureText(separator)
            val fm = paint.fontMetrics
            textHeight = fm.descent - fm.ascent
            val gap = size * GAP_FRACTION
            val pad = size * PAD_FRACTION
            val area = (hourWidth + gap + sepWidth + gap + minuteWidth + pad * 2) *
                (textHeight + pad * 2)
            if (area <= MAX_BITMAP_AREA) return@repeat
            size *= sqrt(MAX_BITMAP_AREA.toFloat() / area)
        }

        paint.textSize = size
        hourWidth = paint.measureText(hours)
        minuteWidth = paint.measureText(minutes)
        sepWidth = paint.measureText(separator)
        val fm = paint.fontMetrics
        textHeight = fm.descent - fm.ascent
        val gap = size * GAP_FRACTION
        val pad = size * PAD_FRACTION
        val totalWidth = hourWidth + gap + sepWidth + gap + minuteWidth

        val bitmap = Bitmap.createBitmap(
            ceil(totalWidth + pad * 2).toInt().coerceAtLeast(1),
            ceil(textHeight + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        Canvas(bitmap).apply {
            val baseline = pad - fm.ascent
            var x = pad
            drawText(hours, x, baseline, paint)
            x += hourWidth + gap
            drawText(separator, x, baseline, paint)
            x += sepWidth + gap
            drawText(minutes, x, baseline, paint)
        }
        return bitmap
    }

    /**
     * Grouped layout drawn with the Noto glyphs: the same cluster arrangement as
     * the geometric mode, but each mark is the bundled typeface's glyph.
     */
    private fun renderNotoClusterTime(
        typeface: Typeface,
        hour: Int,
        minute: Int,
        textSizePx: Float,
        color: Int
    ): Bitmap {
        val separator = SexagesimalCuneiform.TIME_SEPARATOR
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            this.color = color
        }

        var size = textSizePx.coerceAtLeast(1f)
        var hours = layoutCluster(hour, size)
        var minutes = layoutCluster(minute, size)
        var gap = size * GAP_FRACTION
        var pad = size * PAD_FRACTION

        repeat(4) {
            paint.textSize = size
            val sepW = paint.measureText(separator)
            val m = paint.fontMetrics
            val sepH = m.descent - m.ascent
            val gap0 = size * GAP_FRACTION
            val pad0 = size * PAD_FRACTION
            val area = (hours.width + gap0 + sepW + gap0 + minutes.width + pad0 * 2) *
                (maxOf(hours.height, sepH, minutes.height) + pad0 * 2)
            if (area <= MAX_BITMAP_AREA) return@repeat
            size *= sqrt(MAX_BITMAP_AREA.toFloat() / area)
            hours = layoutCluster(hour, size)
            minutes = layoutCluster(minute, size)
            gap = size * GAP_FRACTION
            pad = size * PAD_FRACTION
        }


        paint.textSize = size
        val sepWidth = paint.measureText(separator)
        val fm = paint.fontMetrics
        val sepHeight = fm.descent - fm.ascent
        val totalWidth = hours.width + gap + sepWidth + gap + minutes.width
        val totalHeight = maxOf(hours.height, sepHeight, minutes.height)
        val centerY = pad + totalHeight / 2f

        val bitmap = Bitmap.createBitmap(
            ceil(totalWidth + pad * 2).toInt().coerceAtLeast(1),
            ceil(totalHeight + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        Canvas(bitmap).apply {
            var x = pad
            drawGlyphDigit(this, paint, hours, x, centerY)
            x += hours.width + gap
            val baseline = centerY - (fm.ascent + fm.descent) / 2f
            drawText(separator, x, baseline, paint)
            x += sepWidth + gap
            drawGlyphDigit(this, paint, minutes, x, centerY)
        }
        return bitmap
    }

    private fun renderNotoDigit(
        typeface: Typeface,
        value: Int,
        textSizePx: Float,
        color: Int,
        mode: DisplayMode
    ): Bitmap = when (mode) {
        DisplayMode.CLASSIC -> renderNotoClassicDigit(typeface, value, textSizePx, color)
        DisplayMode.CLUSTER -> renderNotoClusterDigit(typeface, value, textSizePx, color)
    }

    private fun renderNotoClassicDigit(
        typeface: Typeface,
        value: Int,
        textSizePx: Float,
        color: Int
    ): Bitmap {
        val text = SexagesimalCuneiform.digit(value)
        if (text.isEmpty()) {
            return renderFallbackGlyph("", textSizePx, color, typeface)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            this.color = color
            this.textSize = textSizePx.coerceAtLeast(1f)
        }
        val pad = paint.textSize * PAD_FRACTION
        val fm = paint.fontMetrics
        val w = paint.measureText(text)
        return Bitmap.createBitmap(
            ceil(w + pad * 2).toInt().coerceAtLeast(1),
            ceil((fm.descent - fm.ascent) + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        ).also {
            Canvas(it).drawText(text, pad, pad - fm.ascent, paint)
        }
    }

    private fun renderNotoClusterDigit(
        typeface: Typeface,
        value: Int,
        textSizePx: Float,
        color: Int
    ): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            this.color = color
        }
        val size = textSizePx.coerceAtLeast(1f)
        val digit = layoutCluster(value, size)
        val pad = size * PAD_FRACTION
        val bitmap = Bitmap.createBitmap(
            ceil(digit.width + pad * 2).toInt().coerceAtLeast(1),
            ceil(digit.height + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        Canvas(bitmap).apply { drawGlyphDigit(this, paint, digit, pad, pad + digit.height / 2f) }
        return bitmap
    }

    private fun drawGlyphDigit(canvas: Canvas, paint: Paint, digit: Digit, left: Float, centerY: Float) {
        for (cell in digit.cells) {
            val glyph = if (cell.kind == Kind.TEN) SexagesimalCuneiform.TEN else SexagesimalCuneiform.ONE
            paint.textSize = (cell.h * GLYPH_SIZE_FACTOR).coerceAtLeast(1f)
            val fm = paint.fontMetrics
            val glyphWidth = paint.measureText(glyph)
            val x = left + cell.cx - glyphWidth / 2f
            val y = centerY - digit.height / 2f + cell.cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText(glyph, x, y, paint)
        }
    }

    // =========================================================================
    // Fallback
    // =========================================================================

    /** Emergency path: if rendering fails, draw plain "H:MM" with a system font. */
    private fun renderFallback(hour: Int, minute: Int, textSizePx: Float, color: Int): Bitmap {
        val text = "$hour:${minute.toString().padStart(2, '0')}"
        return renderFallbackGlyph(text, textSizePx, color, null)
    }

    private fun renderFallbackGlyph(
        text: String,
        textSizePx: Float,
        color: Int,
        typeface: Typeface?
    ): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface ?: Typeface.SANS_SERIF
            this.textSize = textSizePx.coerceAtLeast(1f)
            this.color = color
        }
        val pad = textSizePx * PAD_FRACTION
        val metrics = paint.fontMetrics
        return Bitmap.createBitmap(
            ceil(paint.measureText(text) + pad * 2).toInt().coerceAtLeast(1),
            ceil((metrics.descent - metrics.ascent) + pad * 2).toInt().coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        ).also {
            Canvas(it).drawText(text, pad, pad - metrics.ascent, paint)
        }
    }
}
