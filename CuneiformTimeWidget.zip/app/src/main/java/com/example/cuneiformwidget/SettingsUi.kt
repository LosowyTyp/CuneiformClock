package com.example.cuneiformwidget

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup

/** Small helpers for building the settings/setup option lists. */
internal object SettingsUi {

    /**
     * Fills [container] with a vertical [RadioGroup] offering [values], the one
     * equal to [selected] checked, invoking [onSelected] on every change.
     */
    fun <T> radioGroup(
        context: Context,
        container: LinearLayout,
        values: List<T>,
        label: (T) -> String,
        selected: T,
        onSelected: (T) -> Unit
    ) {
        container.removeAllViews()
        val group = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        values.forEach { value ->
            val button = RadioButton(context).apply {
                id = View.generateViewId()
                text = label(value)
                isChecked = value == selected
                setOnClickListener { onSelected(value) }
            }
            group.addView(button)
        }
        container.addView(group)
    }
}
