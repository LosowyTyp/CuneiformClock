package com.example.cuneiformwidget

import org.junit.Assert.assertEquals
import org.junit.Test

class OptionEnumsTest {

    @Test
    fun displayModeFallsBackToDefault() {
        assertEquals(DisplayMode.CLUSTER, DisplayMode.fromKey(null))
        assertEquals(DisplayMode.CLUSTER, DisplayMode.fromKey("nope"))
        assertEquals(DisplayMode.CLASSIC, DisplayMode.fromKey("classic"))
    }

    @Test
    fun fontStyleFallsBackToDefault() {
        assertEquals(FontStyle.GEOMETRIC, FontStyle.fromKey(null))
        assertEquals(FontStyle.NOTO_TTF, FontStyle.fromKey("noto_ttf"))
    }

    @Test
    fun inkStyleFallsBackToDefault() {
        assertEquals(InkStyle.CREAM, InkStyle.fromKey(null))
        assertEquals(InkStyle.GOLD, InkStyle.fromKey("gold"))
        assertEquals(InkStyle.WHITE, InkStyle.fromKey("white"))
        assertEquals(InkStyle.YELLOW, InkStyle.fromKey("yellow"))
    }

    @Test
    fun backgroundStyleFallsBackToDefault() {
        assertEquals(BackgroundStyle.CLAY, BackgroundStyle.fromKey(null))
        assertEquals(BackgroundStyle.NIGHT, BackgroundStyle.fromKey("night"))
        assertEquals(BackgroundStyle.LAPIS, BackgroundStyle.fromKey("lapis"))
        assertEquals(BackgroundStyle.TRANSPARENT, BackgroundStyle.fromKey("transparent"))
        assertEquals(
            android.graphics.Color.BLACK,
            BackgroundStyle.TRANSPARENT.windowColor
        )
    }

    @Test
    fun appLanguageFallsBackToEnglish() {
        assertEquals(AppLanguage.ENGLISH, AppLanguage.fromCode(null))
        assertEquals(AppLanguage.POLISH, AppLanguage.fromCode("pl"))
    }
}
