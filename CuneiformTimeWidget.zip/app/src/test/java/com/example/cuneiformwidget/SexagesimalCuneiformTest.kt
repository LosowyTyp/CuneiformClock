package com.example.cuneiformwidget

import org.junit.Assert.assertEquals
import org.junit.Test

class SexagesimalCuneiformTest {

    private val one = SexagesimalCuneiform.ONE
    private val ten = SexagesimalCuneiform.TEN

    @Test
    fun zeroHasNoNativeGlyph() {
        assertEquals("", SexagesimalCuneiform.digit(0))
    }

    @Test
    fun unitsAreRepeatedVerticalWedges() {
        assertEquals(one, SexagesimalCuneiform.digit(1))
        assertEquals(one + one + one, SexagesimalCuneiform.digit(3))
        assertEquals(one.repeat(9), SexagesimalCuneiform.digit(9))
    }

    @Test
    fun tensAreRepeatedWinkelhaken() {
        assertEquals(ten, SexagesimalCuneiform.digit(10))
        assertEquals(ten + ten, SexagesimalCuneiform.digit(20))
        assertEquals(ten.repeat(5), SexagesimalCuneiform.digit(50))
    }

    @Test
    fun tensAndUnitsCombine() {
        assertEquals(ten + ten + one + one + one, SexagesimalCuneiform.digit(23))
        assertEquals(ten.repeat(5) + one.repeat(9), SexagesimalCuneiform.digit(59))
    }

    @Test
    fun arbitraryNumbersUseMultiplePlaces() {
        assertEquals(one + " " + one, SexagesimalCuneiform.of(61))
        // 3600 = 1,0,0 -> one wedge followed by two empty (zero) places.
        assertEquals(one, SexagesimalCuneiform.of(3600).trim())
    }

    @Test
    fun timeSplitsHoursAndMinutes() {
        val expected = SexagesimalCuneiform.digit(9) +
            SexagesimalCuneiform.TIME_SEPARATOR +
            SexagesimalCuneiform.digit(45)
        assertEquals(expected, SexagesimalCuneiform.time(9, 45))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsDigitAboveFiftyNine() {
        SexagesimalCuneiform.digit(60)
    }
}
