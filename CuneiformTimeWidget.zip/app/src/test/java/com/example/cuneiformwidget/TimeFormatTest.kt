package com.example.cuneiformwidget

import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatTest {

    @Test
    fun twelveHourWrapsMidnightToTwelve() {
        assertEquals(12, TimeFormat.hourPlace(0, use24Hour = false))
        assertEquals(1, TimeFormat.hourPlace(1, use24Hour = false))
        assertEquals(11, TimeFormat.hourPlace(11, use24Hour = false))
        assertEquals(12, TimeFormat.hourPlace(12, use24Hour = false))
        assertEquals(1, TimeFormat.hourPlace(13, use24Hour = false))
        assertEquals(11, TimeFormat.hourPlace(23, use24Hour = false))
    }

    @Test
    fun twentyFourHourIsUnchanged() {
        assertEquals(0, TimeFormat.hourPlace(0, use24Hour = true))
        assertEquals(13, TimeFormat.hourPlace(13, use24Hour = true))
        assertEquals(23, TimeFormat.hourPlace(23, use24Hour = true))
    }

    @Test
    fun minutesStayASinglePlace() {
        assertEquals(0, TimeFormat.minutePlace(0))
        assertEquals(59, TimeFormat.minutePlace(59))
        assertEquals(59, TimeFormat.minutePlace(60))
    }
}
