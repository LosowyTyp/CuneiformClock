package com.example.cuneiformwidget

import org.junit.Assert.assertEquals
import org.junit.Test

class CuneiformRendererTest {

    @Test
    fun zeroHasNoUnitRows() {
        assertEquals(emptyList<Int>(), CuneiformRenderer.cuneiformUnitRows(0))
    }

    @Test
    fun oneToThreeUseASingleRow() {
        assertEquals(listOf(1), CuneiformRenderer.cuneiformUnitRows(1))
        assertEquals(listOf(2), CuneiformRenderer.cuneiformUnitRows(2))
        assertEquals(listOf(3), CuneiformRenderer.cuneiformUnitRows(3))
    }

    @Test
    fun fourToSixUseTwoRows() {
        assertEquals(listOf(2, 2), CuneiformRenderer.cuneiformUnitRows(4))
        assertEquals(listOf(3, 2), CuneiformRenderer.cuneiformUnitRows(5))
        assertEquals(listOf(3, 3), CuneiformRenderer.cuneiformUnitRows(6))
    }

    @Test
    fun sevenToNineUseThreeRows() {
        assertEquals(listOf(3, 3, 1), CuneiformRenderer.cuneiformUnitRows(7))
        assertEquals(listOf(3, 3, 2), CuneiformRenderer.cuneiformUnitRows(8))
        assertEquals(listOf(3, 3, 3), CuneiformRenderer.cuneiformUnitRows(9))
    }

    @Test
    fun rowsAlwaysSumToTheUnitCount() {
        for (units in 1..9) {
            assertEquals(units, CuneiformRenderer.cuneiformUnitRows(units).sum())
        }
    }
}
